/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package petshop;

/**
 *
 * @author lucas_g_flores
 */
public class Passaro {
    String estilo_do_bico;
    boolean carnivoro;

    public String getEstilo_do_bico() {
        return estilo_do_bico;
    }

    public void setEstilo_do_bico(String estilo_do_bico) {
        this.estilo_do_bico = estilo_do_bico;
    }

    public boolean isCarnivoro() {
        return carnivoro;
    }

    public void setCarnivoro(boolean carnivoro) {
        this.carnivoro = carnivoro;
    }
    
}
