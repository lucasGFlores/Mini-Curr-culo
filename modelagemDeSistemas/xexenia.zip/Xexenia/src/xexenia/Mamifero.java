/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package xexenia;

/**
 *
 * @author lucas_g_flores
 */
public class Mamifero extends Animal {
    private int mamentacao, gestacao;

    public Mamifero(String especie, String filo, String classe, String ordem, String genero, String familia, String tamanho, int idade, boolean fome) {
        super(especie, filo, classe, ordem, genero, familia, tamanho, idade, fome);
    }

   

}
